﻿using NorthwindWebAPI.Models;
using NorthwindWebAPI.Models.DAO;
using NorthwindWebAPI.Models.VO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web.Http;

namespace NorthwindWebAPI.Controllers
{
    public class ProductosController : ApiController
    {
        [HttpGet]
        [Route("api/productos/consultar")]
        public List<ProductosVO> consultarProductos()
        {
            return new ProductosDAO().consultarProductos();
        }


        [HttpPost]
        [Route("api/productos/registrar")]
        public string RegistrarProductos(FormDataCollection parametros)
        {
            var dao = new ProductosDAO();
            var nuevoProducto = new Products()
            {
                ProductName = parametros["ProductName"],
                SupplierID = int.Parse(parametros["SupplierID"]),
                CategoryID = int.Parse(parametros["CategoryID"]),
                QuantityPerUnit = parametros["QuantityPerUnit"],
                UnitPrice = decimal.Parse(parametros["UnitPrice"]),
                UnitsInStock = short.Parse(parametros["UnitsInStock"]),
                UnitsOnOrder = short.Parse(parametros["UnitsOnOrder"]),
                ReorderLevel = short.Parse(parametros["ReorderLevel"]),
                Discontinued = bool.Parse(parametros["Discontinued"])
            };

            int resultado = dao.registrarProductos(nuevoProducto);
            return (resultado > 0) ? "Se registró el producto" : "Ocurrió un error al registrar el producto";
        }


        [HttpPut]
        [Route("api/productos/modificar")]
        public string modificarProducto(Products products)
        {
            var dao = new ProductosDAO();
            int resultado = dao.modificarProducto(products);
            return (resultado > 0) ? "Se actualizó el producto" : "Ocurrió un error al modificar el producto";
        }

        [HttpDelete]
        [Route("api/productos/eliminar")]
        public string EliminarProductos(Products products)
        {
            var dao = new ProductosDAO();
            int resultado = dao.EliminarProducto(products);
            return (resultado > 0) ? "Se elimino el producto" : "Ocurrió un error al eliminar el producto";
        }
    }
}
