﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthwindWebAPI.Models.VO
{
    public sealed class CategoriaVO : Categories { }

    public sealed class ProductosVO : Products { }
}