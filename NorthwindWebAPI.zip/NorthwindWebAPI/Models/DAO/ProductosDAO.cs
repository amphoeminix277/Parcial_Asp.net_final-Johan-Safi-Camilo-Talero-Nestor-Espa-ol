﻿using NorthwindWebAPI.Models.VO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NorthwindWebAPI.Models.DAO
{
    public class ProductosDAO
    {
        public List<ProductosVO> consultarProductos()
        {
            using (var cnn = new NorthwindEntities())
            {
                return cnn.Products.Select(p => new ProductosVO
                {

                    ProductID = p.ProductID,
                    ProductName = p.ProductName,
                    SupplierID = p.SupplierID,
                    CategoryID = p.CategoryID,
                    QuantityPerUnit = p.QuantityPerUnit,
                    UnitPrice = p.UnitPrice,
                    UnitsInStock = p.UnitsInStock,
                    UnitsOnOrder = p.UnitsOnOrder,
                    ReorderLevel = p.ReorderLevel,
                    Discontinued = p.Discontinued

                }).ToList();
            }
        }


        public int registrarProductos(Products nuevoProducto)
        {
            using (var cnn = new NorthwindEntities())
            {
                cnn.Products.Add(nuevoProducto);
                return cnn.SaveChanges();
            }
        }


        public int modificarProducto(Products nuevosDatosProducto)
        {
            using (var cnn = new NorthwindEntities())
            {
                var anteriorProducto = cnn.Products.SingleOrDefault(p => p.ProductID.Equals(nuevosDatosProducto.ProductID));
                anteriorProducto.ProductName = nuevosDatosProducto.ProductName;
                anteriorProducto.QuantityPerUnit = nuevosDatosProducto.QuantityPerUnit;
                anteriorProducto.UnitPrice = nuevosDatosProducto.UnitPrice;
                anteriorProducto.UnitsInStock = nuevosDatosProducto.UnitsInStock;
                anteriorProducto.UnitsOnOrder = nuevosDatosProducto.UnitsOnOrder;
                anteriorProducto.ReorderLevel = nuevosDatosProducto.ReorderLevel;
                anteriorProducto.Discontinued = nuevosDatosProducto.Discontinued;
                cnn.Entry(anteriorProducto).State = System.Data.Entity.EntityState.Modified;
                return cnn.SaveChanges();
            }
        }
        public int EliminarProducto(Products eliminarDatosProducto)
        {
            using (var cnn = new NorthwindEntities())
            {
                var anteriorProducto = cnn.Products.SingleOrDefault(p => p.ProductID.Equals(eliminarDatosProducto.ProductID));
                anteriorProducto.ProductName = eliminarDatosProducto.ProductName;
                anteriorProducto.QuantityPerUnit = eliminarDatosProducto.QuantityPerUnit;
                anteriorProducto.UnitPrice = eliminarDatosProducto.UnitPrice;
                anteriorProducto.UnitsInStock = eliminarDatosProducto.UnitsInStock;
                anteriorProducto.UnitsOnOrder = eliminarDatosProducto.UnitsOnOrder;
                anteriorProducto.ReorderLevel = eliminarDatosProducto.ReorderLevel;
                anteriorProducto.Discontinued = eliminarDatosProducto.Discontinued;
                cnn.Entry(anteriorProducto).State = System.Data.Entity.EntityState.Deleted;
                return cnn.SaveChanges();
            }
        }
    }
}